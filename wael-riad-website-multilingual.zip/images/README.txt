Place one image per tile in this folder (JPG, about 800x600). The home page hero picks them up automatically;
tiles without an image show a navy/teal/gold gradient.
archcapital.jpg  henrich.jpg  exit-tanzania.jpg  wisepitch.jpg  sentlux.jpg  kabir-kashanch.jpg  shambhavi-metal.jpg
dchange.jpg  fastrac.jpg  iog.jpg  kalmax.jpg  mts-petroleum.jpg  smart-solutions.jpg  georgia-2017.jpg
Use only images you own or have written permission to use.
